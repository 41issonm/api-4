package br.gov.sp.fatec.apipixel.core.domain.projection;

public interface TrilhaColaboradorProjection {

    String getNomeTrilha();
    Long getPorcentagemAndamento();

}
