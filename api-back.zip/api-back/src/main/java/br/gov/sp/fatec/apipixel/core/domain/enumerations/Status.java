package br.gov.sp.fatec.apipixel.core.domain.enumerations;

public enum Status {

    CONCLUIDO, NAO_CONCLUIDO
}
