package br.gov.sp.fatec.apipixel.core.domain.projection;

public interface ColaboradorProjection {
    Long getId();
    String getNome();
}
