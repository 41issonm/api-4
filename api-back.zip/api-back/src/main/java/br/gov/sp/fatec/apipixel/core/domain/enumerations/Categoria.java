package br.gov.sp.fatec.apipixel.core.domain.enumerations;

import jakarta.persistence.Embeddable;

@Embeddable
public enum Categoria {

    SERVICE, SELL;
}
