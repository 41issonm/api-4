package br.gov.sp.fatec.apipixel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPixelApplicationTests {

	@Test
	void contextLoads() {
	}

}
