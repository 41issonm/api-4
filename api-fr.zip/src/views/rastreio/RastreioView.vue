/* eslint-disable */
<style>
.body {
  background-color: #464444;
}
table {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
}
</style>

<template>
    <h2>Tabela com Três Colunas</h2>
</template>

<script lang="ts">
import { Options, Vue } from "vue-class-component";

export default class RastreioView extends Vue {}
</script>
