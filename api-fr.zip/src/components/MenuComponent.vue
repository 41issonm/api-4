<template>
    <div class="container">    
      <img alt="Oracle logo" src="@/assets/logo.png" class="logo" />
      <div class="menu">       
        <nav class="nav-container">
          <router-link to="/rastreio" class="nav-link">
            <img alt="icone de rastreio" src="@/assets/rastreio.png" class="nav-logo" />
          </router-link>
  
          <router-link to="/trilha" class="nav-link">
            <img alt="icone de trilha" src="@/assets/trilha.png" class="nav-logo" />
          </router-link>
  
          <router-link to="/acompanhamento" class="nav-link">
            <img alt="icone de acompanhamento" src="@/assets/acompanhamento.png" class="nav-logo" />
          </router-link>
          <router-link to="/habilidade" class="nav-link">
            <img alt="icone de habilidade" src="@/assets/habilidade.png" class="nav-logo" />   
          </router-link>
        </nav>
      </div>
      <button class="menu-button"><img src="@/assets/menu.png" alt="Menu" style="height: 20px; width: 20px;" /></button>
  
      <hr class="full-width" style="background-color: red; margin-bottom: 20px;" />
  </div>
  </template>
  
  <style>
  body, html {
    margin: 0;
    padding: 0;
  }
  .full-width {
    width: 100%;
    border: none;
    height: 2px;
    background-color: red;
    margin: 10px;
  }
  .menu-button {
  background-color: #464444;
  padding: 5px; 
  margin-left: auto; 
  margin-right: 0; 
  margin-top: -20px; 
}

  .container {
    background-color: #464444;
    min-height: 100vh; 
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  
  .logo {
    height: 2rem;
    margin-right: auto; 
  }
  
  .menu {
    display: flex;
    justify-content: center; 
    width: 100%; 
  }
  
  .nav-container {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
  }
  
  .nav-link {
    border-radius: 50%; 
    padding: 10px 20px; 
    margin: 0 10px; 
    background-color:#A3A3A3; 
    color: #464444; 
    text-decoration: none; 
  }
  
  .nav-link:hover {
    background-color: #ccc; 
  }
  
  .nav-logo {
    height: 1.5rem; 
    margin-right: 3px; 
  }
  
  .full-width {
    width: 100%;
    border: none;
    height: 2px;
    background-color: red;
    margin: 10px;
  }
  </style>
  

  <script>
export default {
  name: 'MenuComponent'
}
</script>
