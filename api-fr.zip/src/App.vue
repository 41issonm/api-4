<template>  
  <div id="app">
    <MenuComponent></MenuComponent>    
    <router-view />
  </div>
  
</template>

<style>
body, html {
  margin: 0;
  padding: 0;
}
.full-width {
  width: 100%;
  border: none;
  height: 2px;
  background-color: red;
  margin: 10px;
}
.menu-button {
  background-color: #464444;
  padding: 10px; /* Ajusta o tamanho do botão */
  margin-top: -20;
  margin-left: auto; /* Move o botão para o canto direito */
  margin-right: 0; /* Remove a margem direita */
}

.container {
  background-color: #464444;
  min-height: 100vh; /* Garante que a cor de fundo ocupe toda a altura da tela */
  display: flex;
  flex-direction: column;
  align-items: center;
}

.logo {
  height: 2rem;
  margin-right: auto; /* Move o logo para o canto esquerdo */
}

.menu {
  display: flex;
  justify-content: center; /* Centraliza horizontalmente */
  width: 100%; /* Garante que ocupe toda a largura */
}

.nav-container {
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}

.nav-link {
  border-radius: 50%; /* Torna o link de navegação um círculo */
  padding: 10px 20px; /* Ajusta o padding para tornar o círculo mais visível */
  margin: 0 10px; /* Adiciona margem entre os links de navegação */
  background-color:#A3A3A3; /* Cor de fundo do círculo */
  color: #464444; /* Cor do texto dentro do círculo */
  text-decoration: none; /* Remove sublinhado padrão */
}

.nav-link:hover {
  background-color: #ccc; /* Cor de fundo do círculo ao passar o mouse */
}

.nav-logo {
  height: 1.5rem; /* Altura do logo dentro do link */
  margin-right: 3px; /* Espaçamento entre o logo e o texto */
}

.full-width {
  width: 100%;
  border: none;
  height: 2px;
  background-color: red;
  margin: 10px;
}
</style>

<script>
import MenuComponent from './components/MenuComponent.vue';

export default {
  name: 'App',
  components: {
    MenuComponent
  }
}</script>